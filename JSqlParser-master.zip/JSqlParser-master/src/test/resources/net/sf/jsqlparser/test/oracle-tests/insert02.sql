-- insert pl/sql recond
insert into t values trec
