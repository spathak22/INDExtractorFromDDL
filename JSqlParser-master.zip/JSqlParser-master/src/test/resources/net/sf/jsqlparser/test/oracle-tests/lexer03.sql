select :1, :X, :1 + 1, 1 + :2 from A where A=:3 and b= :4 and c= :5 and :A = :b

