select * from dual t1,
(
	(
		(
			dual t2 join dual t3 using(dummy) )
			left outer join dual t4 using(dummy) )
			left outer join dual t5 using(dummy) )

			
			