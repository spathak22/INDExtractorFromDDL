select 'A' | | 'B'  from dual

