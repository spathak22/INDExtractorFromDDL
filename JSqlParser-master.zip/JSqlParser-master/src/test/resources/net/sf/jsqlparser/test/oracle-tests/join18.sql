select department_id as d_e_dept_id, e.last_name
   from departments
   full outer join employees on (a=b)
   left outer join employees on (a=b)
   right outer join employees on (a=b)
   join employees on (a=b)
   inner join employees on (a=b)
   cross join employees
   natural join employees




	
