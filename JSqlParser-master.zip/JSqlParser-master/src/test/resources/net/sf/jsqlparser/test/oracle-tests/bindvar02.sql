select *
from a
where a=:3
and b= :4
and c= :5 and :a = :b

